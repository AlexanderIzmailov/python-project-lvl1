from random import randint
from brain_games.games.logic import take_name, question, result


def even_game():
    name = take_name()
    print("Answer 'yes' if the number is even, otherwise answer 'no'.")

    i = 0
    while i != 3:
        number = randint(0, 100)
        is_even = "yes" if number % 2 == 0 else "no"
        question(str(number))

        if result(is_even, name):
            i += 1
        else:
            return

    print("Congratulations, " + name + "!")
