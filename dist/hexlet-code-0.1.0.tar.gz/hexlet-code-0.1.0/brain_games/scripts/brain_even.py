from brain_games.games.even import even_game


def main():
    even_game()


if __name__ == '__main__':
    main()
